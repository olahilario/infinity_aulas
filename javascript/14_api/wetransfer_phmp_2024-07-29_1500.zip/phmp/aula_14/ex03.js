btn_submit = document.getElementById('btn_submit')
btn_submit.addEventListener('onsubmit', getAddress)

form = document.getElementById('form_cep')


form.addEventListener('onsubmit', (e)=>{
    e.preventDefault()})



function getAddress(){



}
